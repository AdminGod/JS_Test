let msg = "";

for(let i = 1; i <= 9; i++){
    msg += "7 x " + i + " = " + 7*i + "\n";
}
alert(msg);
console.log(msg);