let msg = ""

for(let i = 654; i >= 0; i--){
    msg += i + "; ";
}
alert(msg);
console.log(msg);