let sum = 0;

for(let i = 0; i <= 100; i++){
    sum+=i;
}
alert("sum numbers from 0 >> 100 = " + sum);