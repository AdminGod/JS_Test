let msg = "";

for(let i = 1000; i <= 2000; i++){
    msg += "&#" + i + "; ";
}
alert(msg);
console.log(msg);