let msg = ""

for(let i = 4; i <= 13; i+=3){
    msg += i + "; ";
}
alert(msg);
