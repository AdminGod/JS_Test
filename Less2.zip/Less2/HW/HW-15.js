let msg = ""

for(let i = -4; i <= 100; i+=2){
    msg += i + "; ";
}
alert(msg);
console.log(msg);