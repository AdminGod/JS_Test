let msg = ""

for(let i = 4; i <= 400; i+=4){
    msg += i + "; ";
}
alert(msg);