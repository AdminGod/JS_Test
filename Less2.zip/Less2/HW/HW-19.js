let multiplication = 1;

for(let i = 1; i <= 50; i++){
    multiplication*=i;
}
alert("multiplication of numbers from 1 >> 50 = " + multiplication);