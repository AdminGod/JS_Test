let msg = ""

for(let i = 1983; i <= 2017; i++){
    msg += i + "; ";
}
alert(msg);
console.log(msg);